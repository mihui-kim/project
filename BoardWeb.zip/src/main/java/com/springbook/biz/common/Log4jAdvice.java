package com.springbook.biz.common;

public class Log4jAdvice {
	
	public void printLogging() {
		System.out.println("[공통로그-Log4j] 비지니스 로직 수행 전 동작");
	}

}
