package com.springbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardWebJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoardWebJpaApplication.class, args);
	}

}

