package com.springbook.repository;

public class BoardRepository2 {

}
